<?php

/**
 * @author: VLThemes
 * @version: 1.0
 */

dynamic_sidebar( 'blog_sidebar' );