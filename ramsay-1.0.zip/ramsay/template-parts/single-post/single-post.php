<?php

/**
 * @author: VLThemes
 * @version: 1.0
 */

if ( is_active_sidebar( 'blog_sidebar' ) ) {
	$column_content_class = 'col-md-8';
} else {
	$column_content_class = 'col-md-12';
}

$column_sidebar_class = 'col-md-4';

$size = 'ramsay-1280x720_crop';
$post_class = 'vlt-post vlt-post--style-single';

?>

<div class="container">

	<div class="row">

		<div class="<?php echo ramsay_sanitize_class( $column_content_class ); ?>">

			<article <?php post_class( $post_class ); ?>>

				<?php if ( has_post_thumbnail() ) : ?>

					<div class="vlt-post-thumbnail">
						<?php echo wp_get_attachment_image( get_post_thumbnail_id( get_the_ID() ), $size ); ?>
					</div>
					<!-- /.vlt-post-thumbnail -->

				<?php endif; ?>

				<div class="vlt-post-content clearfix">
					<?php get_template_part( 'template-parts/single-post/partials/partial-post', 'content' ); ?>
				</div>
				<!-- /.vlt-post-content -->

				<footer class="vlt-post-footer">
					<?php get_template_part( 'template-parts/single-post/partials/partial-post', 'footer' ); ?>
				</footer>
				<!-- /.vlt-post-footer -->

			</article>
			<!-- /.vlt-post -->

			<?php

				if ( comments_open() || get_comments_number() ) {
					comments_template();
				}

			?>

		</div>

		<?php if ( is_active_sidebar( 'blog_sidebar' ) ) : ?>

			<div class="<?php echo ramsay_sanitize_class( $column_sidebar_class ); ?>">

				<div class="vlt-sidebar vlt-sidebar--right">

					<?php get_sidebar(); ?>

				</div>

			</div>

		<?php endif; ?>

	</div>

</div>
<!-- /.container -->