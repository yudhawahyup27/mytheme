<?php

/**
 * @author: VLThemes
 * @version: 1.0
 */

?>

<div class="vlt-post-meta">

	<span><time datetime="<?php the_time( 'c' ); ?>"><?php echo get_the_date(); ?></time></span>

	<?php if ( ramsay_get_post_taxonomy( get_the_ID(), 'category' ) ) : ?>
		<span><?php echo ramsay_get_post_taxonomy( get_the_ID(), 'category', ', ' ); ?></span>
	<?php endif; ?>

</div>
<!-- /.vlt-post-meta -->