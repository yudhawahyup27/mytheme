<?php

/**
 * @author: VLThemes
 * @version: 1.0
 */

?>

<h2 class="vlt-post-title"><?php the_title(); ?></h2>
<!-- /.vlt-post-title -->