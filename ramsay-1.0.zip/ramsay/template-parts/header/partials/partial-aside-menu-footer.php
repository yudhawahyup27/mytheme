<?php

/**
 * @author: VLThemes
 * @version: 1.0
 */

?>

<div class="vlt-aside-menu__footer">

	<?php if ( ramsay_get_theme_mod( 'aside_menu_socials_list' ) ) : ?>

		<div class="vlt-aside-menu__socials">
			<?php
				foreach ( ramsay_get_theme_mod( 'aside_menu_socials_list' ) as $socialItem ) :
					echo '<a class="vlt-social-icon" href="' . esc_url( $socialItem[ 'social_url' ] ) . '" target="_blank"><i class="' . ramsay_sanitize_class( $socialItem[ 'social_icon' ] ) . '"></i></a>';
				endforeach;
			?>
		</div>
		<!-- /.vlt-aside-menu__socials -->

	<?php endif; ?>

	<?php if ( ramsay_get_theme_mod( 'header_copyright' ) ) : ?>

		<div class="vlt-aside-menu__copyright"><?php echo wp_kses_post( ramsay_get_theme_mod( 'header_copyright' ) ); ?></div>
		<!-- /.vlt-aside-menu__copyright -->

	<?php endif; ?>

</div>
<!-- /.vlt-aside-menu__footer -->