<?php

/**
 * @author: VLThemes
 * @version: 1.0
 */

?>

<div class="vlt-aside-menu__header">

	<a href="#" class="vlt-menu-burger vlt-menu-burger--opened">
		<span class="line line-one"><span></span></span>
		<span class="line line-two"><span></span></span>
		<span class="line line-three"><span></span></span>
	</a>
	<!-- /.vlt-menu-burger -->

</div>
<!-- /.vlt-aside-menu__header -->