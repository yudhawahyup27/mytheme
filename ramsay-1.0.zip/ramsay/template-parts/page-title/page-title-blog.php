
<?php

/**
 * @author: VLThemes
 * @version: 1.0
 */

?>

<div class="vlt-page-title">

	<div class="container">

		<h1><?php echo esc_html( ramsay_get_theme_mod( 'blog_title' ) ); ?></h1>

		<?php echo ramsay_get_breadcrumbs(); ?>

	</div>

</div>
<!-- /.vlt-page-title -->