<?php

/**
 * @author: VLThemes
 * @version: 1.0
 */

?>

<div class="vlt-page-title">

	<div class="container">

		<h1><?php esc_html_e( 'Archive', 'ramsay' ); ?></h1>

		<?php echo ramsay_get_breadcrumbs(); ?>

	</div>

</div>
<!-- /.vlt-page-title -->