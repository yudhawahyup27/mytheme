/***********************************************
 * RAMSAY: NAVBAR
 ***********************************************/
(function($) {
	'use strict';

	var navbarMain = $('.vlt-navbar--main');
	var navbarHeight = navbarMain.outerHeight();
	var navbarMainOffset = 0;

	// fake navbar
	var navbarFake = $('<div class="vlt-fake-navbar">').hide();

	// fixed navbar
	function _fixed_navbar() {
		navbarMain.addClass('vlt-navbar--fixed');
		navbarFake.show();
		// add solid color
		if (navbarMain.hasClass('vlt-navbar--transparent') && navbarMain.hasClass('vlt-navbar--sticky')) {
			navbarMain.addClass('vlt-navbar--solid');
		}
	}

	function _unfixed_navbar() {
		navbarMain.removeClass('vlt-navbar--fixed');
		navbarFake.hide();
		// remove solid color
		if (navbarMain.hasClass('vlt-navbar--transparent') && navbarMain.hasClass('vlt-navbar--sticky')) {
			navbarMain.removeClass('vlt-navbar--solid');
		}
	}

	function _on_scroll_navbar() {
		if (VLTJS.window.scrollTop() > navbarMainOffset) {
			_fixed_navbar();
		} else {
			_unfixed_navbar();
		}
	}

	if (navbarMain.hasClass('vlt-navbar--sticky')) {
		VLTJS.window.on('scroll resize', _on_scroll_navbar);
		_on_scroll_navbar();
		// append fake navbar
		navbarMain.after(navbarFake);
		// fake navbar height after resize
		navbarFake.height(navbarHeight);
		VLTJS.debounceResize(function() {
			navbarFake.height(navbarHeight);
		});
	}
})(jQuery);

/***********************************************
 * HEADER ASIDE
 ***********************************************/
(function($) {
	'use strict';

	var menuAside = $('.vlt-aside-menu-wrapper ul.sf-menu'),
		menuOverlay = $('.vlt-aside-menu-overlay'),
		menuContacts = $('.vlt-navbar-contacts'),
		menuToggle = $('.vlt-menu-burger'),
		onepageLinks = menuAside.filter('.sf-menu-onepage').find('a'),
		menuIsOpen = false;

	menuContacts.find('li + li').before('<li class="sep">/</li>');

	// check if plugin defined
	if (typeof $.fn.superclick !== 'undefined') {
		menuAside.superclick({
			delay: 300,
			cssArrows: false,
			animation: {
				opacity: 'show',
				height: 'show'
			},
			animationOut: {
				opacity: 'hide',
				height: 'hide'
			},
		});
	}

	function _open_menu() {
		menuOverlay.fadeIn(300);
		if (typeof anime !== 'undefined') {
			anime.timeline({
				easing: 'easeInOutQuad',
				delay: 0
			}).add({
				targets: '.vlt-aside-menu-wrapper',
				duration: 600,
				translateX: ['100%', 0]
			}).add({
				targets: ['.vlt-aside-menu__navigation', '.vlt-aside-menu__socials', '.vlt-aside-menu__copyright'],
				duration: 500,
				delay: anime.stagger(150),
				translateY: [50, 0],
				opacity: [0, 1],
				loop: false
			});
		}
		menuIsOpen = true;
	}

	function _close_menu() {
		menuOverlay.fadeOut(300);
		if (typeof anime !== 'undefined') {
			anime.timeline({
				easing: 'easeInOutQuad',
				delay: 0
			}).add({
				targets: '.vlt-aside-menu-wrapper',
				duration: 400,
				translateX: [0, '100%']
			}).add({
				targets: ['.vlt-aside-menu__navigation', '.vlt-aside-menu__socials', '.vlt-aside-menu__copyright'],
				duration: 0,
				translateY: [0, 50],
				opacity: [1, 0]
			});
		}
		menuIsOpen = false;
	}
	menuToggle.on('click', function(e) {
		e.preventDefault();
		if (!menuIsOpen) {
			_open_menu();
		} else {
			_close_menu();
		}
	});
	menuOverlay.on('click', function(e) {
		e.preventDefault();
		_close_menu();
	});
	onepageLinks.on('click', function(e) {
		_close_menu();
	});
	$(document).on('keyup', function(e) {
		if (e.keyCode === 27) {
			_close_menu();
		}
	});
})(jQuery);
/***********************************************
 * RAMSAY: OTHER SCRIPTS
 ***********************************************/
(function ($) {
	'use strict';

	// Fitvids
	if (typeof $.fn.fitVids !== 'undefined') {
		VLTJS.body.fitVids({
			ignore: 'object'
		});
	}

	// Widget menu
	if (typeof $.fn.superclick !== 'undefined') {
		$('.widget_pages > ul, .widget_nav_menu ul.menu').superclick({
			delay: 300,
			cssArrows: false,
			animation: {
				opacity: 'show',
				height: 'show'
			},
			animationOut: {
				opacity: 'hide',
				height: 'hide'
			},
		});
	}

	// Fast click
	if (typeof FastClick === 'function') {
		FastClick.attach(document.body);
	}

})(jQuery);
/***********************************************
 * RAMSAY: PRELOADER
 ***********************************************/
(function ($) {
	'use strict';
	// check if plugin defined
	if (typeof $.fn.animsition == 'undefined') {
		return;
	}
	var animsitionClass = $('.animsition');
	animsitionClass.animsition({
		inDuration: 500,
		outDuration: 500,
		linkElement: 'a:not([target="_blank"]):not([href^="#"]):not([rel="nofollow"]):not([href~="#"]):not([href^=mailto]):not([href^=tel]):not(.sf-with-ul)',
		loadingClass: 'animsition-loading-2',
		loadingInner: '<div class="spinner"><span class="double-bounce-one"></span><span class="double-bounce-two"></span></div>',
	});
	animsitionClass.on('animsition.inEnd', function () {
		VLTJS.window.trigger('vlt.preloader_done');
		VLTJS.html.addClass('vlt-is-page-loaded');
	});
})(jQuery);
/***********************************************
 * WIDGET: CONTACT FORM 7
 ***********************************************/
(function($){

	'use strict';

	var VLThemesContactForm7 = function($scope, $) {

		// Remove unused tags
		$('.wpcf7-form').find('p').contents().unwrap();
		$('.wpcf7-form').find('p, br').remove();

	};

	VLTJS.window.on('elementor/frontend/init', function() {
		elementorFrontend.hooks.addAction(
			'frontend/element_ready/vlt-contact-form-7.default',
			VLThemesContactForm7
		);
	});

})(jQuery);
/***********************************************
 * WIDGET: FULLPAGE SLIDER
 ***********************************************/
(function($) {

	'use strict';

	var VLThemesFullpageSlider = function($scope, $) {

		// check if plugin defined
		if (typeof anime == 'undefined') {
			return;
		}

		var el = $scope.find('.vlt-fullpage-slider'),
			loop_top = el.data('loop-top') ? true : false,
			loop_bottom = el.data('loop-bottom') ? true : false,
			speed = el.data('speed') || 280,
			dots = el.data('dots') ? {} : false,
			anchors = [];

		if (typeof $.fn.pagepiling == 'undefined') {
			return;
		}

		VLTJS.body.css('overflow', 'hidden');
		VLTJS.html.css('overflow', 'hidden');

		el.find('[data-anchor]').each(function() {
			anchors.push($(this).data('anchor'));
		});

		function navbarFullpage() {
			if (el.find('.pp-section.active').scrollTop() > 0) {
				$('.vlt-navbar').addClass('vlt-navbar--solid');
			} else {
				$('.vlt-navbar').removeClass('vlt-navbar--solid');
			}
		}
		navbarFullpage();

		el.pagepiling({
			menu: '.sf-menu',
			scrollingSpeed: speed,
			loopTop: loop_top,
			loopBottom: loop_bottom,
			anchors: anchors,
			verticalCentered: true,
			sectionSelector: '.vlt-section',
			navigation: dots,
			afterLoad: function(anchorLink, index){
				navbarFullpage();
			}
		});

		el.find('.pp-scrollable').on('scroll', function () {
			var scrollTop = $(this).scrollTop();
			if (scrollTop > 0 ) {
				$('.vlt-navbar').addClass('vlt-navbar--solid');
			} else{
				$('.vlt-navbar').removeClass('vlt-navbar--solid');
			}
		});

		$('#pp-nav').remove().appendTo(el).addClass('vlt-right-boxed hidden-xs');

		$('.vlt-resume')
		.on('mouseover',function(){
			$(this).parents('.vlt-section').find('.has-mask').addClass('hide');
		})
		.on('mouseleave', function () {
			$(this).parents('.vlt-section').find('.has-mask').removeClass('hide');
		});

		$('.vlt-project-detail').eq(0).addClass('is-active');
		$('.vlt-section__background-changer .vlt-section__background').eq(0).addClass('is-active');

		$('.vlt-project-detail').on('mouseover',function(){
			var index = $(this).index();
			$('.vlt-project-detail').removeClass('is-active');
			$(this).addClass('is-active');
			$('.vlt-section__background-changer .vlt-section__background').removeClass('is-active').eq(index).addClass('is-active');
		});

	}

	VLTJS.window.on('elementor/frontend/init', function() {
		elementorFrontend.hooks.addAction(
			'frontend/element_ready/vlt-fullpage-slider.default',
			VLThemesFullpageSlider
		);
	});

})(jQuery);
/***********************************************
 * WIDGET: PILING PROJECTS
 ***********************************************/
(function($) {

	'use strict';

	var VLThemesPilingProjects = function($scope, $) {

		// check if plugin defined
		if (typeof anime == 'undefined') {
			return;
		}

		var el = $scope.find('.vlt-piling-projects'),
			loop_top = el.data('loop-top') ? true : false,
			loop_bottom = el.data('loop-bottom') ? true : false,
			speed = el.data('speed') || 280,
			dots = el.data('dots') ? {} : false,
			anchors = [];

		if (typeof $.fn.pagepiling == 'undefined') {
			return;
		}

		VLTJS.body.css('overflow', 'hidden');
		VLTJS.html.css('overflow', 'hidden');

		el.find('[data-anchor]').each(function() {
			anchors.push($(this).data('anchor'));
		});

		el.pagepiling({
			scrollingSpeed: speed,
			loopTop: loop_top,
			loopBottom: loop_bottom,
			anchors: anchors,
			verticalCentered: false,
			sectionSelector: '.vlt-section',
			navigation: dots,
			onLeave: function(index, nextIndex, direction) {
				el.find('.vlt-project-detail__title').eq(index -1 ).removeClass('out').addClass('in');
				el.find('.vlt-project-detail__title').eq(nextIndex -1 ).removeClass('in').addClass('out');
			},
		});

		$('#pp-nav').remove().appendTo(el).addClass('vlt-right-boxed hidden-xs');

	}

	VLTJS.window.on('elementor/frontend/init', function() {
		elementorFrontend.hooks.addAction(
			'frontend/element_ready/vlt-piling-projects.default',
			VLThemesPilingProjects
		);
	});

})(jQuery);
/***********************************************
 * WIDGET: TESTIMONIAL SLIDER
 ***********************************************/
(function($) {

	'use strict';

	var VLThemesTestimonialSlider = function($scope, $) {

		// check if plugin defined
		if (typeof $.fn.owlCarousel == 'undefined') {
			return;
		}

		var el = $scope.find('.vlt-testimonial'),
			loop = el.data('loop') || false;

		el.owlCarousel({
			responsive: {
				0: {
					items: 1
				},
				720: {
					items: 1,
				},
				1280: {
					items: 1
				}
			},
			responsiveRefreshRate: 0,
			loop: loop,
			nav: false,
			navText:[],
			dots: true
		});

	}

	VLTJS.window.on('elementor/frontend/init', function() {
		elementorFrontend.hooks.addAction(
			'frontend/element_ready/vlt-testimonial-slider.default',
			VLThemesTestimonialSlider
		);
	});

})(jQuery);