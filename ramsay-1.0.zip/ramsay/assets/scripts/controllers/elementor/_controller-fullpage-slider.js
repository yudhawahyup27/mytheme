/***********************************************
 * WIDGET: FULLPAGE SLIDER
 ***********************************************/
(function($) {

	'use strict';

	var VLThemesFullpageSlider = function($scope, $) {

		// check if plugin defined
		if (typeof anime == 'undefined') {
			return;
		}

		var el = $scope.find('.vlt-fullpage-slider'),
			loop_top = el.data('loop-top') ? true : false,
			loop_bottom = el.data('loop-bottom') ? true : false,
			speed = el.data('speed') || 280,
			dots = el.data('dots') ? {} : false,
			anchors = [];

		if (typeof $.fn.pagepiling == 'undefined') {
			return;
		}

		VLTJS.body.css('overflow', 'hidden');
		VLTJS.html.css('overflow', 'hidden');

		el.find('[data-anchor]').each(function() {
			anchors.push($(this).data('anchor'));
		});

		function navbarFullpage() {
			if (el.find('.pp-section.active').scrollTop() > 0) {
				$('.vlt-navbar').addClass('vlt-navbar--solid');
			} else {
				$('.vlt-navbar').removeClass('vlt-navbar--solid');
			}
		}
		navbarFullpage();

		el.pagepiling({
			menu: '.sf-menu',
			scrollingSpeed: speed,
			loopTop: loop_top,
			loopBottom: loop_bottom,
			anchors: anchors,
			verticalCentered: true,
			sectionSelector: '.vlt-section',
			navigation: dots,
			afterLoad: function(anchorLink, index){
				navbarFullpage();
			}
		});

		el.find('.pp-scrollable').on('scroll', function () {
			var scrollTop = $(this).scrollTop();
			if (scrollTop > 0 ) {
				$('.vlt-navbar').addClass('vlt-navbar--solid');
			} else{
				$('.vlt-navbar').removeClass('vlt-navbar--solid');
			}
		});

		$('#pp-nav').remove().appendTo(el).addClass('vlt-right-boxed hidden-xs');

		$('.vlt-resume')
		.on('mouseover',function(){
			$(this).parents('.vlt-section').find('.has-mask').addClass('hide');
		})
		.on('mouseleave', function () {
			$(this).parents('.vlt-section').find('.has-mask').removeClass('hide');
		});

		$('.vlt-project-detail').eq(0).addClass('is-active');
		$('.vlt-section__background-changer .vlt-section__background').eq(0).addClass('is-active');

		$('.vlt-project-detail').on('mouseover',function(){
			var index = $(this).index();
			$('.vlt-project-detail').removeClass('is-active');
			$(this).addClass('is-active');
			$('.vlt-section__background-changer .vlt-section__background').removeClass('is-active').eq(index).addClass('is-active');
		});

	}

	VLTJS.window.on('elementor/frontend/init', function() {
		elementorFrontend.hooks.addAction(
			'frontend/element_ready/vlt-fullpage-slider.default',
			VLThemesFullpageSlider
		);
	});

})(jQuery);