/***********************************************
 * WIDGET: PILING PROJECTS
 ***********************************************/
(function($) {

	'use strict';

	var VLThemesPilingProjects = function($scope, $) {

		// check if plugin defined
		if (typeof anime == 'undefined') {
			return;
		}

		var el = $scope.find('.vlt-piling-projects'),
			loop_top = el.data('loop-top') ? true : false,
			loop_bottom = el.data('loop-bottom') ? true : false,
			speed = el.data('speed') || 280,
			dots = el.data('dots') ? {} : false,
			anchors = [];

		if (typeof $.fn.pagepiling == 'undefined') {
			return;
		}

		VLTJS.body.css('overflow', 'hidden');
		VLTJS.html.css('overflow', 'hidden');

		el.find('[data-anchor]').each(function() {
			anchors.push($(this).data('anchor'));
		});

		el.pagepiling({
			scrollingSpeed: speed,
			loopTop: loop_top,
			loopBottom: loop_bottom,
			anchors: anchors,
			verticalCentered: false,
			sectionSelector: '.vlt-section',
			navigation: dots,
			onLeave: function(index, nextIndex, direction) {
				el.find('.vlt-project-detail__title').eq(index -1 ).removeClass('out').addClass('in');
				el.find('.vlt-project-detail__title').eq(nextIndex -1 ).removeClass('in').addClass('out');
			},
		});

		$('#pp-nav').remove().appendTo(el).addClass('vlt-right-boxed hidden-xs');

	}

	VLTJS.window.on('elementor/frontend/init', function() {
		elementorFrontend.hooks.addAction(
			'frontend/element_ready/vlt-piling-projects.default',
			VLThemesPilingProjects
		);
	});

})(jQuery);