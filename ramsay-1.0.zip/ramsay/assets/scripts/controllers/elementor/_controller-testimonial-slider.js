/***********************************************
 * WIDGET: TESTIMONIAL SLIDER
 ***********************************************/
(function($) {

	'use strict';

	var VLThemesTestimonialSlider = function($scope, $) {

		// check if plugin defined
		if (typeof $.fn.owlCarousel == 'undefined') {
			return;
		}

		var el = $scope.find('.vlt-testimonial'),
			loop = el.data('loop') || false;

		el.owlCarousel({
			responsive: {
				0: {
					items: 1
				},
				720: {
					items: 1,
				},
				1280: {
					items: 1
				}
			},
			responsiveRefreshRate: 0,
			loop: loop,
			nav: false,
			navText:[],
			dots: true
		});

	}

	VLTJS.window.on('elementor/frontend/init', function() {
		elementorFrontend.hooks.addAction(
			'frontend/element_ready/vlt-testimonial-slider.default',
			VLThemesTestimonialSlider
		);
	});

})(jQuery);