/***********************************************
 * RAMSAY: NAVBAR
 ***********************************************/
(function($) {
	'use strict';

	var navbarMain = $('.vlt-navbar--main');
	var navbarHeight = navbarMain.outerHeight();
	var navbarMainOffset = 0;

	// fake navbar
	var navbarFake = $('<div class="vlt-fake-navbar">').hide();

	// fixed navbar
	function _fixed_navbar() {
		navbarMain.addClass('vlt-navbar--fixed');
		navbarFake.show();
		// add solid color
		if (navbarMain.hasClass('vlt-navbar--transparent') && navbarMain.hasClass('vlt-navbar--sticky')) {
			navbarMain.addClass('vlt-navbar--solid');
		}
	}

	function _unfixed_navbar() {
		navbarMain.removeClass('vlt-navbar--fixed');
		navbarFake.hide();
		// remove solid color
		if (navbarMain.hasClass('vlt-navbar--transparent') && navbarMain.hasClass('vlt-navbar--sticky')) {
			navbarMain.removeClass('vlt-navbar--solid');
		}
	}

	function _on_scroll_navbar() {
		if (VLTJS.window.scrollTop() > navbarMainOffset) {
			_fixed_navbar();
		} else {
			_unfixed_navbar();
		}
	}

	if (navbarMain.hasClass('vlt-navbar--sticky')) {
		VLTJS.window.on('scroll resize', _on_scroll_navbar);
		_on_scroll_navbar();
		// append fake navbar
		navbarMain.after(navbarFake);
		// fake navbar height after resize
		navbarFake.height(navbarHeight);
		VLTJS.debounceResize(function() {
			navbarFake.height(navbarHeight);
		});
	}
})(jQuery);

/***********************************************
 * HEADER ASIDE
 ***********************************************/
(function($) {
	'use strict';

	var menuAside = $('.vlt-aside-menu-wrapper ul.sf-menu'),
		menuOverlay = $('.vlt-aside-menu-overlay'),
		menuContacts = $('.vlt-navbar-contacts'),
		menuToggle = $('.vlt-menu-burger'),
		onepageLinks = menuAside.filter('.sf-menu-onepage').find('a'),
		menuIsOpen = false;

	menuContacts.find('li + li').before('<li class="sep">/</li>');

	// check if plugin defined
	if (typeof $.fn.superclick !== 'undefined') {
		menuAside.superclick({
			delay: 300,
			cssArrows: false,
			animation: {
				opacity: 'show',
				height: 'show'
			},
			animationOut: {
				opacity: 'hide',
				height: 'hide'
			},
		});
	}

	function _open_menu() {
		menuOverlay.fadeIn(300);
		if (typeof anime !== 'undefined') {
			anime.timeline({
				easing: 'easeInOutQuad',
				delay: 0
			}).add({
				targets: '.vlt-aside-menu-wrapper',
				duration: 600,
				translateX: ['100%', 0]
			}).add({
				targets: ['.vlt-aside-menu__navigation', '.vlt-aside-menu__socials', '.vlt-aside-menu__copyright'],
				duration: 500,
				delay: anime.stagger(150),
				translateY: [50, 0],
				opacity: [0, 1],
				loop: false
			});
		}
		menuIsOpen = true;
	}

	function _close_menu() {
		menuOverlay.fadeOut(300);
		if (typeof anime !== 'undefined') {
			anime.timeline({
				easing: 'easeInOutQuad',
				delay: 0
			}).add({
				targets: '.vlt-aside-menu-wrapper',
				duration: 400,
				translateX: [0, '100%']
			}).add({
				targets: ['.vlt-aside-menu__navigation', '.vlt-aside-menu__socials', '.vlt-aside-menu__copyright'],
				duration: 0,
				translateY: [0, 50],
				opacity: [1, 0]
			});
		}
		menuIsOpen = false;
	}
	menuToggle.on('click', function(e) {
		e.preventDefault();
		if (!menuIsOpen) {
			_open_menu();
		} else {
			_close_menu();
		}
	});
	menuOverlay.on('click', function(e) {
		e.preventDefault();
		_close_menu();
	});
	onepageLinks.on('click', function(e) {
		_close_menu();
	});
	$(document).on('keyup', function(e) {
		if (e.keyCode === 27) {
			_close_menu();
		}
	});
})(jQuery);