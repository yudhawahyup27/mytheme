<?php

/**
 * @author: VLThemes
 * @version: 1.0
 */

/**
 * Register sidebars
 */
if ( ! function_exists( 'ramsay_register_sidebar' ) ) {
	function ramsay_register_sidebar() {
		register_sidebar( array(
			'name' => esc_html__( 'Blog Sidebar', 'ramsay' ),
			'id' => 'blog_sidebar',
			'description' => esc_html__( 'Blog Widget Area', 'ramsay' ),
			'before_widget' => '<div id="%1$s" class="vlt-widget %2$s">',
			'after_widget' => '</div>',
			'before_title' => '<h5 class="vlt-widget__title">',
			'after_title' => '</h5>'
		) );
	}
}
add_action( 'widgets_init', 'ramsay_register_sidebar' );

/**
 * Before site wrapper
 */
if ( ! function_exists( 'ramsay_before_site_wrapper' ) ) {
	function ramsay_before_site_wrapper() {
		$class = 'vlt-site-wrapper';

		// preloader
		if ( ramsay_get_theme_mod( 'preloader' ) == 'show' ) {
			$class .= ' animsition';
		}

		echo '<div class="' . ramsay_sanitize_class( $class ) . '">';
	}
}
add_action( 'ramsay/before_site_wrapper', 'ramsay_before_site_wrapper' );

/**
 * After site wrapper
 */
if ( ! function_exists( 'ramsay_after_site_wrapper' ) ) {
	function ramsay_after_site_wrapper() {
		echo '</div>';
	}
}
add_action( 'ramsay/after_site_wrapper', 'ramsay_after_site_wrapper' );

/**
 * Change admin logo
 */
if ( ! function_exists( 'ramsay_change_admin_logo' ) ) {
	function ramsay_change_admin_logo() {
		if ( ! ramsay_get_theme_mod( 'login_logo_image' ) ) {
			return;
		}
		$image_url = ramsay_get_theme_mod( 'login_logo_image' );
		$image_w = ramsay_get_theme_mod( 'login_logo_image_width' );
		$image_h = ramsay_get_theme_mod( 'login_logo_image_height' );
		echo '<style type="text/css">
			h1 a {
				background: transparent url(' . esc_url( $image_url ) . ') 50% 50% no-repeat !important;
				width:' . esc_attr( $image_w ) . '!important;
				height:' . esc_attr( $image_h ) . '!important;
				background-size: cover !important;
			}
		</style>';
	}
}
add_action( 'login_head', 'ramsay_change_admin_logo' );

/**
 * Prints Tracking code
 */
if ( ! function_exists( 'ramsay_print_tracking_code' ) ) {
	function ramsay_print_tracking_code() {
		$tracking_code = ramsay_get_theme_mod( 'tracking_code' );
		if ( ! empty( $tracking_code ) ) {
			echo '' . $tracking_code;
		}
	}
}
add_action( 'wp_head', 'ramsay_print_tracking_code' );