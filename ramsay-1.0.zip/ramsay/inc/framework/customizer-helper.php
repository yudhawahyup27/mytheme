<?php

/**
 * @author: VLThemes
 * @version: 1.0
 */

/**
* Theme path image
*/
$theme_path_images = RAMSAY_THEME_DIRECTORY . 'assets/img/';

/**
 * Wrapper for Kirki
 */
if ( ! class_exists( 'VLT_Options' ) ) {
	class VLT_Options {

		private static $default_options = array();

		public static function add_config( $args ) {
			if ( class_exists( 'Kirki' ) && isset( $args ) && is_array( $args ) ) {
				Kirki::add_config( 'ramsay_customize', $args );
			}
		}

		public static function add_panel( $name, $args ) {
			if ( class_exists( 'Kirki' ) && isset( $args ) && is_array( $args ) ) {
				Kirki::add_panel( $name, $args );
			}
		}

		public static function add_section( $name, $args ) {
			if ( class_exists( 'Kirki' ) && isset( $args ) && is_array( $args ) ) {
				Kirki::add_section( $name, $args );
			}
		}

		public static function add_field( $args ) {
			if ( isset( $args ) && is_array( $args ) ) {
				if ( class_exists( 'Kirki' ) ) {
					Kirki::add_field( 'ramsay_customize', $args );
				}
				if ( isset( $args['settings'] ) && isset( $args['default'] ) ) {
					self::$default_options[$args['settings']] = $args['default'];
				}
			}
		}

		public static function get_option( $name, $default = null ) {
			$value = get_theme_mod( $name, null );

			if ( $value === null ) {
				$value = isset( self::$default_options[$name] ) ? self::$default_options[$name] : null;
			}

			if ( $value === null ) {
				$value = $default;
			}

			return $value;
		}

	}
}

/**
 * Custom get_theme_mod
 */
if ( ! function_exists( 'ramsay_get_theme_mod' ) ) {
	function ramsay_get_theme_mod( $name = null, $use_acf = null, $postID = null, $acf_name = null ) {

		$value = null;

		if ( $name == null ) {
			return $value;
		}

		// try get value from meta box
		if ( $use_acf ) {
			$value = ramsay_get_field( $acf_name ? $acf_name : $name, $postID );
		}

		// get value from options
		if ( $value == null ) {
			if ( class_exists( 'VLT_Options' ) ) {
				$value = VLT_Options::get_option( $name );
			}
		}

		if ( is_archive() || is_search() || is_404() ) {
			if ( class_exists( 'VLT_Options' ) ) {
				$value = VLT_Options::get_option( $name );
			}
		}

		$value = apply_filters( 'ramsay/get_theme_mod', $value, $name );

		return $value;

	}
}

/**
 * Get value from acf field
 */
if ( ! function_exists( 'ramsay_get_field' ) ) {
	function ramsay_get_field( $name = null, $postID = null ) {

		$value = null;

		// try get value from meta box
		if ( function_exists( 'get_field' ) ) {
			if ( $postID == null ) {
				$postID = get_the_ID();
			}
			$value = get_field( $name, $postID );
		}

		return $value;

	}
}

/**
 * Get social icons
 */
if ( ! function_exists( 'ramsay_get_social_icons' ) ) {
	function ramsay_get_social_icons() {
		$social_icons = array(
			'ion-social-android' => esc_html__( 'Android', 'ramsay' ),
			'ion-social-angular' => esc_html__( 'Angular', 'ramsay' ),
			'ion-social-apple' => esc_html__( 'Apple', 'ramsay' ),
			'ion-social-bitcoin' => esc_html__( 'Bitcoin', 'ramsay' ),
			'ion-social-buffer' => esc_html__( 'Buffer', 'ramsay' ),
			'ion-social-chrome' => esc_html__( 'Chrome', 'ramsay' ),
			'ion-social-codepen' => esc_html__( 'Codepen', 'ramsay' ),
			'ion-social-css3' => esc_html__( 'CSS3', 'ramsay' ),
			'ion-social-designernews' => esc_html__( 'Buffer', 'ramsay' ),
			'ion-social-dribbble' => esc_html__( 'Dribbble', 'ramsay' ),
			'ion-social-dropbox' => esc_html__( 'Dropbox', 'ramsay' ),
			'ion-social-euro' => esc_html__( 'Euro', 'ramsay' ),
			'ion-social-facebook' => esc_html__( 'Facebook', 'ramsay' ),
			'ion-social-foursquare' => esc_html__( 'Foursquare', 'ramsay' ),
			'ion-social-freebsd-devil' => esc_html__( 'Dreebsd Devil', 'ramsay' ),
			'ion-social-github' => esc_html__( 'Github', 'ramsay' ),
			'ion-social-google' => esc_html__( 'Google', 'ramsay' ),
			'ion-social-googleplus' => esc_html__( 'GooglePlus', 'ramsay' ),
			'ion-social-hackernews' => esc_html__( 'HackerNews', 'ramsay' ),
			'ion-social-html5' => esc_html__( 'HTML5', 'ramsay' ),
			'ion-social-instagram' => esc_html__( 'Instagram', 'ramsay' ),
			'ion-social-javascript' => esc_html__( 'Javascript', 'ramsay' ),
			'ion-social-linkedin' => esc_html__( 'LinkedIn', 'ramsay' ),
			'ion-social-markdown' => esc_html__( 'Markdown', 'ramsay' ),
			'ion-social-nodejs' => esc_html__( 'NodeJS', 'ramsay' ),
			'ion-social-octocat' => esc_html__( 'Octocat', 'ramsay' ),
			'ion-social-pinterest' => esc_html__( 'Pinterest', 'ramsay' ),
			'ion-social-python' => esc_html__( 'Python', 'ramsay' ),
			'ion-social-reddit' => esc_html__( 'Reddit', 'ramsay' ),
			'ion-social-rss' => esc_html__( 'RSS', 'ramsay' ),
			'ion-social-sass' => esc_html__( 'SASS', 'ramsay' ),
			'ion-social-skype' => esc_html__( 'Skype', 'ramsay' ),
			'ion-social-snapchat' => esc_html__( 'Snapchat', 'ramsay' ),
			'ion-social-tumblr' => esc_html__( 'Tumblr', 'ramsay' ),
			'ion-social-tux' => esc_html__( 'Tux', 'ramsay' ),
			'ion-social-twitch' => esc_html__( 'Twitch', 'ramsay' ),
			'ion-social-twitter' => esc_html__( 'Twitter', 'ramsay' ),
			'ion-social-usd' => esc_html__( 'USD', 'ramsay' ),
			'ion-social-vimeo' => esc_html__( 'Vimeo', 'ramsay' ),
			'ion-social-whatsapp' => esc_html__( 'WhatsApp', 'ramsay' ),
			'ion-social-windows' => esc_html__( 'Windows', 'ramsay' ),
			'ion-social-wordpress' => esc_html__( 'WordPress', 'ramsay' ),
			'ion-social-yahoo' => esc_html__( 'Yahoo', 'ramsay' ),
			'ion-social-yen' => esc_html__( 'Yen', 'ramsay' ),
			'ion-social-youtube' => esc_html__( 'YouTube', 'ramsay' )
		);
		return apply_filters( 'ramsay/get_social_icons', $social_icons );
	}
}

/**
 * Add custom choice
 */
if ( ! function_exists( 'ramsay_add_custom_choice' ) ) {
	function ramsay_add_custom_choice() {
		return array(
			'fonts' => apply_filters( 'vlthemes/kirki_font_choices', array() )
		);
	}
}