<?php

/**
 * @author: VLThemes
 * @version: 1.0
 */

if ( ! function_exists( 'ramsay_dynamic_css' ) ) {
	function ramsay_dynamic_css( $css ) {
		$css .= '';

		return $css;
	}
}
add_filter( 'kirki_ramsay_customize_dynamic_css', 'ramsay_dynamic_css' );