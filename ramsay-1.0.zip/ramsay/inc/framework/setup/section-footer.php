<?php

/**
 * @author: VLThemes
 * @version: 1.0
 */

$priority = 0;

/**
 * Footer general
 */
VLT_Options::add_field( array(
	'type' => 'custom',
	'settings' => 'sfg_1',
	'section' => 'section_footer_general',
	'default' => '<div class="kirki-separator">' . esc_html__( 'General', 'ramsay' ) . '</div>',
	'priority' => $priority++,
) );

VLT_Options::add_field( array(
	'type' => 'select',
	'settings' => 'footer_show',
	'section' => 'section_footer_general',
	'label' => esc_html__( 'Footer Show', 'ramsay' ),
	'priority' => $priority++,
	'transport' => 'auto',
	'choices' => array(
		'show' => esc_html__( 'Show', 'ramsay' ),
		'hide' => esc_html__( 'Hide', 'ramsay' ),
	),
	'default' => 'show',
) );

VLT_Options::add_field( array(
	'type' => 'select',
	'settings' => 'footer_fixed',
	'section' => 'section_footer_general',
	'label' => esc_html__( 'Footer Fixed', 'ramsay' ),
	'priority' => $priority++,
	'transport' => 'auto',
	'choices' => array(
		'enable' => esc_html__( 'Enable', 'ramsay' ),
		'disable' => esc_html__( 'Disable', 'ramsay' )
	),
	'active_callback' => array(
		array(
			'setting' => 'footer_show',
			'operator' => '==',
			'value' => 'show',
		)
	),
	'default' => 'disable',
) );

VLT_Options::add_field( array(
	'type' => 'editor',
	'settings' => 'footer_copyright',
	'section' => 'section_footer_general',
	'label' => esc_html__( 'Copyright', 'ramsay' ),
	'priority' => $priority++,
	'transport' => 'auto',
	'default' => '<p>© Ramsay 2020.</p>',
) );

VLT_Options::add_field( array(
	'type' => 'custom',
	'settings' => 'sfg_2',
	'section' => 'section_footer_general',
	'default' => '<div class="kirki-separator">' . esc_html__( 'Socials', 'ramsay' ) . '</div>',
	'priority' => $priority++,
) );

VLT_Options::add_field( array(
	'type' => 'repeater',
	'settings' => 'footer_social_list',
	'section' => 'section_footer_general',
	'label' => esc_html__( 'Social List', 'ramsay' ),
	'priority' => $priority++,
	'transport' => 'auto',
	'row_label' => array(
		'type' => 'text',
		'value' => esc_html__( 'social', 'ramsay' )
	),
	'fields' => array(
		'social_icon' => array(
			'type' => 'select',
			'label' => esc_html__( 'Social Icon', 'ramsay' ),
			'choices' => ramsay_get_social_icons()
		),
		'social_url' => array(
			'type' => 'text',
			'label' => esc_html__( 'Social Url', 'ramsay' )
		),
	),
	'default' => ''
) );