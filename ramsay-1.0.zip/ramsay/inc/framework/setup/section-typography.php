<?php

/**
 * @author: VLThemes
 * @version: 1.0
 */

$priority = 0;

/**
 * General fonts
 */
VLT_Options::add_field( array(
	'type' => 'typography',
	'settings' => 'primary_font',
	'section' => 'typography_fonts',
	'label' => esc_html__( 'Primary Font', 'ramsay' ),
	'priority' => $priority++,
	'transport' => 'auto',
	'choices' => array(
		'variant' => array( '300', 'regular', '600' ),
	),
	'default' => array(
		'font-family' => 'Poppins'
	),
	'output' => array(
		array(
			'choice' => 'font-family',
			'element' => ':root',
			'property' => '--pf',
			'context' => array( 'editor', 'front' ),
		)
	)
) );

VLT_Options::add_field( array(
	'type' => 'typography',
	'settings' => 'secondary_font',
	'section' => 'typography_fonts',
	'label' => esc_html__( 'Secondary Font', 'ramsay' ),
	'priority' => $priority++,
	'transport' => 'auto',
	'choices' => array(
		'variant' => array( 'regular', '500', '600' ),
	),
	'default' => array(
		'font-family' => 'Montserrat'
	),
	'output' => array(
		array(
			'choice' => 'font-family',
			'element' => ':root',
			'property' => '--sf',
			'context' => array( 'editor', 'front' ),
		)
	)
) );

/**
 * Body typography
 */
VLT_Options::add_field( array(
	'type' => 'typography',
	'settings' => 'base_typography',
	'section' => 'typography_text',
	'label' => esc_html__( 'Base Typography', 'ramsay' ),
	'priority' => $priority++,
	'transport' => 'auto',
	'choices' => ramsay_add_custom_choice(),
	'default' => array(
		'font-family' => 'Poppins',
		'variant' => 'regular',
		'font-size' => '1rem',
		'line-height' => '1.9428',
		'color' => '#888888',
		'letter-spacing' => '0.025em',
		'text-transform' => 'none'
	),
	'output' => array(
		array(
			'element' => 'body'
		),
		array(
			'element' => '.edit-post-visual-editor.editor-styles-wrapper',
			'context' => array( 'editor' ),
		),
	)
) );

/**
 * Heading typography
 */
VLT_Options::add_field( array(
	'type' => 'typography',
	'settings' => 'typography_h1_titles',
	'section' => 'typography_headings',
	'label' => esc_html__( 'H1 Titles', 'ramsay' ),
	'priority' => $priority++,
	'transport' => 'auto',
	'choices' => ramsay_add_custom_choice(),
	'default' => array(
		'font-family' => 'Montserrat',
		'variant' => '600',
		'font-size' => '3.428rem',
		'line-height' => '1.2',
		'color' => '#ffffff',
		'letter-spacing' => '-0.025em',
		'text-transform' => 'none'
	),
	'output' => array(
		array(
			'element' => 'h1, .h1'
		),
		array(
			'element' => '.edit-post-visual-editor.editor-styles-wrapper h1, .edit-post-visual-editor.editor-styles-wrapper .editor-post-title__input',
			'context' => array( 'editor' ),
		),
	)
) );

VLT_Options::add_field( array(
	'type' => 'typography',
	'settings' => 'typography_h2_titles',
	'section' => 'typography_headings',
	'label' => esc_html__( 'H2 Titles', 'ramsay' ),
	'priority' => $priority++,
	'transport' => 'auto',
	'choices' => ramsay_add_custom_choice(),
	'default' => array(
		'font-family' => 'Montserrat',
		'variant' => '600',
		'font-size' => '3.371rem',
		'line-height' => '1.166',
		'color' => '#ffffff',
		'letter-spacing' => '0',
		'text-transform' => 'none'
	),
	'output' => array(
		array(
			'element' => 'h2, .h2'
		),
		array(
			'element' => '.edit-post-visual-editor.editor-styles-wrapper h2',
			'context' => array( 'editor' ),
		),
	)
) );

VLT_Options::add_field( array(
	'type' => 'typography',
	'settings' => 'typography_h3_titles',
	'section' => 'typography_headings',
	'label' => esc_html__( 'H3 Titles', 'ramsay' ),
	'priority' => $priority++,
	'transport' => 'auto',
	'choices' => ramsay_add_custom_choice(),
	'default' => array(
		'font-family' => 'Montserrat',
		'variant' => '600',
		'font-size' => '2.142rem',
		'line-height' => '1.2',
		'color' => '#ffffff',
		'letter-spacing' => '-0.05em',
		'text-transform' => 'none'
	),
	'output' => array(
		array(
			'element' => 'h3, .h3'
		),
		array(
			'element' => '.edit-post-visual-editor.editor-styles-wrapper h3',
			'context' => array( 'editor' ),
		),
	)
) );

VLT_Options::add_field( array(
	'type' => 'typography',
	'settings' => 'typography_h4_titles',
	'section' => 'typography_headings',
	'label' => esc_html__( 'H4 Titles', 'ramsay' ),
	'priority' => $priority++,
	'transport' => 'auto',
	'choices' => ramsay_add_custom_choice(),
	'default' => array(
		'font-family' => 'Montserrat',
		'variant' => '600',
		'font-size' => '1.714rem',
		'line-height' => '1.25',
		'color' => '#ffffff',
		'letter-spacing' => '0.025em;',
		'text-transform' => 'none'
	),
	'output' => array(
		array(
			'element' => 'h4, .h4'
		),
		array(
			'element' => '.edit-post-visual-editor.editor-styles-wrapper h4',
			'context' => array( 'editor' ),
		),
	)
) );

VLT_Options::add_field( array(
	'type' => 'typography',
	'settings' => 'typography_h5_titles',
	'section' => 'typography_headings',
	'label' => esc_html__( 'H5 Titles', 'ramsay' ),
	'priority' => $priority++,
	'transport' => 'auto',
	'choices' => ramsay_add_custom_choice(),
	'default' => array(
		'font-family' => 'Montserrat',
		'variant' => '600',
		'font-size' => '1.571rem',
		'line-height' => '1.1',
		'color' => '#ffffff',
		'letter-spacing' => '0',
		'text-transform' => 'none'
	),
	'output' => array(
		array(
			'element' => 'h5, .h5'
		),
		array(
			'element' => '.edit-post-visual-editor.editor-styles-wrapper h5',
			'context' => array( 'editor' ),
		),
	)
) );

VLT_Options::add_field( array(
	'type' => 'typography',
	'settings' => 'typography_h6_titles',
	'section' => 'typography_headings',
	'label' => esc_html__( 'H6 Titles', 'ramsay' ),
	'priority' => $priority++,
	'transport' => 'auto',
	'choices' => ramsay_add_custom_choice(),
	'default' => array(
		'font-family' => 'Montserrat',
		'variant' => '600',
		'font-size' => '1.285rem', // 16px
		'line-height' => '1.3333',
		'color' => '#ffffff',
		'letter-spacing' => '0',
		'text-transform' => 'none'
	),
	'output' => array(
		array(
			'element' => 'h6, .h6'
		),
		array(
			'element' => '.edit-post-visual-editor.editor-styles-wrapper h6',
			'context' => array( 'editor' ),
		),
	)
) );

/**
 * Blockquote typography
 */
VLT_Options::add_field( array(
	'type' => 'typography',
	'settings' => 'blockquote_typography',
	'section' => 'typography_blockquote',
	'label' => esc_html__( 'Blockquote', 'ramsay' ),
	'priority' => $priority++,
	'transport' => 'auto',
	'choices' => ramsay_add_custom_choice(),
	'default' => array(
		'font-family' => 'Poppins',
		'variant' => '300',
		'font-size' => '1.275rem',
		'line-height' => '1.675',
		'letter-spacing' => '0',
		'text-transform' => 'none'
	),
	'output' => array(
		array(
			'element' => 'blockquote'
		),
		array(
			'element' => '.wp-block-quote, .wp-block-pullquote',
			'context' => array( 'editor' ),
		),
	)
) );

/**
 * Button typography
 */
VLT_Options::add_field( array(
	'type' => 'typography',
	'settings' => 'typography_button',
	'section' => 'typography_buttons',
	'label' => esc_html__( 'Button Typography', 'ramsay' ),
	'priority' => $priority++,
	'transport' => 'auto',
	'choices' => ramsay_add_custom_choice(),
	'default' => array(
		'font-family' => 'Poppins',
		'variant' => 'regular',
		'font-size' => '1rem',
		'line-height' => '1.5',
		'letter-spacing' => '0.025em',
		'text-transform' => 'none'
	),
	'output' => array(
		array(
			'element' => '.vlt-btn'
		)
	)
) );

/**
 * Input typography
 */
VLT_Options::add_field( array(
	'type' => 'typography',
	'settings' => 'typography_input',
	'section' => 'typography_input',
	'label' => esc_html__( 'Input Typography', 'ramsay' ),
	'priority' => $priority++,
	'transport' => 'auto',
	'choices' => ramsay_add_custom_choice(),
	'default' => array(
		'font-family' => 'Poppins',
		'variant' => 'regular',
		'font-size' => '1rem', // 16px
		'letter-spacing' => '0',
		'line-height' => '1.9428',
		'text-transform' => 'none'
	),
	'output' => array(
		array(
			'element' => '
				input[type="text"],
				input[type="date"],
				input[type="email"],
				input[type="password"],
				input[type="tel"],
				input[type="url"],
				input[type="search"],
				input[type="number"],
				textarea,
				select
			'
		)
	)
) );

VLT_Options::add_field( array(
	'type' => 'typography',
	'settings' => 'typography_label',
	'section' => 'typography_input',
	'label' => esc_html__( 'Label Typography', 'ramsay' ),
	'priority' => $priority++,
	'transport' => 'auto',
	'choices' => ramsay_add_custom_choice(),
	'default' => array(
		'font-family' => 'Montserrat',
		'variant' => 'regular',
		'font-size' => '1rem',
		'line-height' => '1.5',
		'letter-spacing' => '0',
		'text-transform' => 'none'
	),
	'output' => array(
		array(
			'element' => 'label'
		)
	)
) );

/**
 * Widget title typography
 */
VLT_Options::add_field( array(
	'type' => 'typography',
	'settings' => 'typography_widget_title',
	'section' => 'typography_widget',
	'label' => esc_html__( 'Widget Title Typography', 'ramsay' ),
	'priority' => $priority++,
	'transport' => 'auto',
	'choices' => ramsay_add_custom_choice(),
	'default' => array(
		'font-family' => 'Montserrat',
		'variant' => '600',
		'font-size' => '1.5rem',
		'line-height' => '1.1',
		'letter-spacing' => '0',
		'text-transform' => 'none'
	),
	'output' => array(
		array(
			'element' => '.vlt-widget__title'
		)
	)
) );