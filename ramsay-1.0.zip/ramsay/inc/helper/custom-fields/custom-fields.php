<?php

if( function_exists('acf_add_local_field_group') ):

	acf_add_local_field_group(array(
		'key' => 'group_5bc26122a92ad',
		'title' => '[Page] Overrides',
		'fields' => array(
			array(
				'key' => 'field_5bc318c304751',
				'label' => 'Navigation',
				'name' => '',
				'type' => 'tab',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array(
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'placement' => 'top',
				'endpoint' => 0,
			),
			array(
				'key' => 'field_5bc26126286c2',
				'label' => 'Custom Navigation',
				'name' => 'page_custom_navigation',
				'type' => 'true_false',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array(
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'message' => '',
				'default_value' => 0,
				'ui' => 1,
				'ui_on_text' => '',
				'ui_off_text' => '',
			),
			array(
				'key' => 'field_5bc33c5551a6c',
				'label' => 'Navigation Show',
				'name' => 'navigation_show',
				'type' => 'select',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => array(
					array(
						array(
							'field' => 'field_5bc26126286c2',
							'operator' => '==',
							'value' => '1',
						),
					),
				),
				'wrapper' => array(
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'choices' => array(
					'show' => 'Show',
					'hide' => 'Hide',
				),
				'default_value' => array(
				),
				'allow_null' => 1,
				'multiple' => 0,
				'ui' => 0,
				'return_format' => 'value',
				'ajax' => 0,
				'placeholder' => '',
			),
			array(
				'key' => 'field_5bc3a717dfaa9',
				'label' => 'Navigation Opaque',
				'name' => 'navigation_opaque',
				'type' => 'select',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => array(
					array(
						array(
							'field' => 'field_5bc26126286c2',
							'operator' => '==',
							'value' => '1',
						),
						array(
							'field' => 'field_5bc33c5551a6c',
							'operator' => '==',
							'value' => 'show',
						),
						array(
							'field' => 'field_5bc3406c8a592',
							'operator' => '!=',
							'value' => 'aside',
						),
					),
				),
				'wrapper' => array(
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'choices' => array(
					'enable' => 'Enable',
					'disable' => 'Disable',
				),
				'default_value' => array(
				),
				'allow_null' => 1,
				'multiple' => 0,
				'ui' => 0,
				'return_format' => 'value',
				'ajax' => 0,
				'placeholder' => '',
			),
			array(
				'key' => 'field_5bc3a769dfaac',
				'label' => 'Transparent',
				'name' => 'navigation_transparent',
				'type' => 'select',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => array(
					array(
						array(
							'field' => 'field_5bc26126286c2',
							'operator' => '==',
							'value' => '1',
						),
						array(
							'field' => 'field_5bc33c5551a6c',
							'operator' => '==',
							'value' => 'show',
						),
						array(
							'field' => 'field_5bc3406c8a592',
							'operator' => '!=',
							'value' => 'aside',
						),
					),
				),
				'wrapper' => array(
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'choices' => array(
					'enable' => 'Enable',
					'disable' => 'Disable',
				),
				'default_value' => array(
				),
				'allow_null' => 1,
				'multiple' => 0,
				'ui' => 0,
				'return_format' => 'value',
				'ajax' => 0,
				'placeholder' => '',
			),
			array(
				'key' => 'field_5bc3a788dfaad',
				'label' => 'Transparent Always',
				'name' => 'navigation_transparent_always',
				'type' => 'select',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => array(
					array(
						array(
							'field' => 'field_5bc26126286c2',
							'operator' => '==',
							'value' => '1',
						),
						array(
							'field' => 'field_5bc33c5551a6c',
							'operator' => '==',
							'value' => 'show',
						),
						array(
							'field' => 'field_5bc3406c8a592',
							'operator' => '!=',
							'value' => 'aside',
						),
					),
				),
				'wrapper' => array(
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'choices' => array(
					'enable' => 'Enable',
					'disable' => 'Disable',
				),
				'default_value' => array(
				),
				'allow_null' => 1,
				'multiple' => 0,
				'ui' => 0,
				'return_format' => 'value',
				'ajax' => 0,
				'placeholder' => '',
			),
			array(
				'key' => 'field_5bc3a7a1dfaae',
				'label' => 'Sticky',
				'name' => 'navigation_sticky',
				'type' => 'select',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => array(
					array(
						array(
							'field' => 'field_5bc26126286c2',
							'operator' => '==',
							'value' => '1',
						),
						array(
							'field' => 'field_5bc33c5551a6c',
							'operator' => '==',
							'value' => 'show',
						),
						array(
							'field' => 'field_5bc3406c8a592',
							'operator' => '!=',
							'value' => 'aside',
						),
					),
				),
				'wrapper' => array(
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'choices' => array(
					'enable' => 'Enable',
					'disable' => 'Disable',
				),
				'default_value' => array(
				),
				'allow_null' => 1,
				'multiple' => 0,
				'ui' => 0,
				'return_format' => 'value',
				'ajax' => 0,
				'placeholder' => '',
			),
			array(
				'key' => 'field_5bc31a3995664',
				'label' => 'Footer',
				'name' => '',
				'type' => 'tab',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array(
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'placement' => 'top',
				'endpoint' => 0,
			),
			array(
				'key' => 'field_5bc31a7895666',
				'label' => 'Custom Footer',
				'name' => 'page_custom_footer',
				'type' => 'true_false',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array(
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'message' => '',
				'default_value' => 0,
				'ui' => 1,
				'ui_on_text' => '',
				'ui_off_text' => '',
			),
			array(
				'key' => 'field_5bc31aef95668',
				'label' => 'Footer Show',
				'name' => 'footer_show',
				'type' => 'select',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => array(
					array(
						array(
							'field' => 'field_5bc31a7895666',
							'operator' => '==',
							'value' => '1',
						),
					),
				),
				'wrapper' => array(
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'choices' => array(
					'show' => 'Show',
					'hide' => 'Hide',
				),
				'default_value' => array(
				),
				'allow_null' => 1,
				'multiple' => 0,
				'ui' => 0,
				'return_format' => 'value',
				'ajax' => 0,
				'placeholder' => '',
			),
			array(
				'key' => 'field_5bc31ab095667',
				'label' => 'Footer Fixed',
				'name' => 'footer_fixed',
				'type' => 'select',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => array(
					array(
						array(
							'field' => 'field_5bc31a7895666',
							'operator' => '==',
							'value' => '1',
						),
						array(
							'field' => 'field_5bc31aef95668',
							'operator' => '==',
							'value' => 'show',
						),
					),
				),
				'wrapper' => array(
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'choices' => array(
					'enable' => 'Enable',
					'disable' => 'Disable',
				),
				'default_value' => array(
				),
				'allow_null' => 1,
				'multiple' => 0,
				'ui' => 0,
				'return_format' => 'value',
				'ajax' => 0,
				'placeholder' => '',
			),
			array(
				'key' => 'field_5e02525c09efd',
				'label' => 'Onepage Navigation',
				'name' => '',
				'type' => 'tab',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array(
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'placement' => 'top',
				'endpoint' => 0,
			),
			array(
				'key' => 'field_5e02523009efc',
				'label' => 'Onepage Navigation',
				'name' => 'onepage_navigation',
				'type' => 'true_false',
				'instructions' => '',
				'required' => 0,
				'conditional_logic' => 0,
				'wrapper' => array(
					'width' => '',
					'class' => '',
					'id' => '',
				),
				'message' => '',
				'default_value' => 0,
				'ui' => 1,
				'ui_on_text' => '',
				'ui_off_text' => '',
			),
		),
		'location' => array(
			array(
				array(
					'param' => 'post_type',
					'operator' => '==',
					'value' => 'post',
				),
			),
			array(
				array(
					'param' => 'post_type',
					'operator' => '==',
					'value' => 'page',
				),
			),
			array(
				array(
					'param' => 'post_type',
					'operator' => '==',
					'value' => 'portfolio',
				),
			),
		),
		'menu_order' => 0,
		'position' => 'normal',
		'style' => 'default',
		'label_placement' => 'top',
		'instruction_placement' => 'label',
		'hide_on_screen' => '',
		'active' => true,
		'description' => '',
	));

	endif;